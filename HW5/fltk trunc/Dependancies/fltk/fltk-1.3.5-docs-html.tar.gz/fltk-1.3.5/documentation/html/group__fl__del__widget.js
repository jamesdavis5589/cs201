var group__fl__del__widget =
[
    [ "clear_widget_pointer", "group__fl__del__widget.html#gad3cbd31083b47836cbe00ffb7006a4d4", null ],
    [ "delete_widget", "group__fl__del__widget.html#ga609413ac47ba433d1e7da8678a27164f", null ],
    [ "do_widget_deletion", "group__fl__del__widget.html#ga838010444986ae57301d6e8289d2dfbb", null ],
    [ "release_widget_pointer", "group__fl__del__widget.html#ga1426329d09de561319d4555018d9d1a2", null ],
    [ "watch_widget_pointer", "group__fl__del__widget.html#ga16ecd6d20b793fd0f3081eaab369caa9", null ]
];