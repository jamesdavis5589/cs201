var classFl__Plugin__Manager =
[
    [ "Fl_Plugin_Manager", "classFl__Plugin__Manager.html#a925e0caea1944ad56fded0c4d8f2e1fb", null ],
    [ "~Fl_Plugin_Manager", "classFl__Plugin__Manager.html#a1cad84738f8549ff1efa857ade308c77", null ],
    [ "addPlugin", "classFl__Plugin__Manager.html#a8164ddc304b93f62a28c33c3da45af05", null ],
    [ "plugin", "classFl__Plugin__Manager.html#a011f00cd299954fd229fc0d3fbcffca5", null ],
    [ "plugin", "classFl__Plugin__Manager.html#a0b544ffc787a497bddc4f5f69ebd5e91", null ],
    [ "plugins", "classFl__Plugin__Manager.html#a4c454afe90d1f532a12d0a9db7de27fe", null ]
];