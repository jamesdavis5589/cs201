var structFl__Glut__StrokeChar =
[
    [ "Number", "structFl__Glut__StrokeChar.html#a5aacc8ddaa5fd865f3d4d231022b3310", null ],
    [ "Right", "structFl__Glut__StrokeChar.html#a270526ffef05a9d90fa321a972c80962", null ],
    [ "Strips", "structFl__Glut__StrokeChar.html#a1d95554587a166eee949ea16f35d1b02", null ]
];