var classFl__Text__Selection =
[
    [ "end", "classFl__Text__Selection.html#a6e212e08bac071f7847863a67bc3ea6a", null ],
    [ "includes", "classFl__Text__Selection.html#a3dd3ddc20191fb623cd3497748e12c3e", null ],
    [ "position", "classFl__Text__Selection.html#a9cdcad64dfb79f687455687fb98eb357", null ],
    [ "selected", "classFl__Text__Selection.html#a79f26408243fc616d056e42183c7253f", null ],
    [ "selected", "classFl__Text__Selection.html#a7bff68583fce36fa09474112c204d1a6", null ],
    [ "set", "classFl__Text__Selection.html#a93c52e97b24fe3afd0a3668bb93426ac", null ],
    [ "start", "classFl__Text__Selection.html#ac9c4fb69c164190da6448d1ec52f82bf", null ],
    [ "update", "classFl__Text__Selection.html#ad8fa85320dcc990fb1baa4adc6cf81d0", null ],
    [ "Fl_Text_Buffer", "classFl__Text__Selection.html#a9b1dbbeb788827f7e2c822a6b14d4a83", null ],
    [ "mEnd", "classFl__Text__Selection.html#ac2871c01124862070a9eb68af7c0b171", null ],
    [ "mSelected", "classFl__Text__Selection.html#a7ed85098de59ea67762b54cbccb08c0e", null ],
    [ "mStart", "classFl__Text__Selection.html#ae4abfc4286beaabbca38c42a2681d730", null ]
];