var classFl__Plugin =
[
    [ "Fl_Plugin", "classFl__Plugin.html#a968b52aedafd49c59efe074a45dbfdd5", null ],
    [ "~Fl_Plugin", "classFl__Plugin.html#aad6ac33a7ee6200c2ec14cc4b5a1de6e", null ]
];