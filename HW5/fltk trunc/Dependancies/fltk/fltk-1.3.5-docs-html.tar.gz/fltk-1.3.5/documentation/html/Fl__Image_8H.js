var Fl__Image_8H =
[
    [ "Fl_Image", "classFl__Image.html", "classFl__Image" ],
    [ "Fl_RGB_Image", "classFl__RGB__Image.html", "classFl__RGB__Image" ],
    [ "Fl_RGB_Scaling", "Fl__Image_8H.html#a79b21b0aede6293a7521b40ff6196368", [
      [ "FL_RGB_SCALING_NEAREST", "Fl__Image_8H.html#a79b21b0aede6293a7521b40ff6196368ab3d220f85e1cde2e88ce74512e7a80af", null ],
      [ "FL_RGB_SCALING_BILINEAR", "Fl__Image_8H.html#a79b21b0aede6293a7521b40ff6196368ad4908fc3630eabed1601e67e18bcd179", null ]
    ] ]
];