var structFl__XColor =
[
    [ "b", "structFl__XColor.html#a1f520c4069d93450251e35b99859868d", null ],
    [ "g", "structFl__XColor.html#a85a1562037c26437f4a2877eb8464725", null ],
    [ "mapped", "structFl__XColor.html#a81bffe1ae124df5a4b8d51ff3b1c280f", null ],
    [ "pixel", "structFl__XColor.html#a3dfbd5d25eb2c2f57f42c671e89b833e", null ],
    [ "r", "structFl__XColor.html#aa5cc60e4bd120fa9720a5c37116bdb7b", null ]
];