var classFl__Native__File__Chooser =
[
    [ "Option", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49cac", [
      [ "NO_OPTIONS", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49caca3068710db5d9f81647aa268e85b260dc", null ],
      [ "SAVEAS_CONFIRM", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49cacabfab604347c2b3d0a09e48fab085f756", null ],
      [ "NEW_FOLDER", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49caca133986ecd600cf1713b058b6bf76ce75", null ],
      [ "PREVIEW", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49caca64cbe46ed2f545a659a91233116e0dd2", null ],
      [ "USE_FILTER_EXT", "classFl__Native__File__Chooser.html#ac848ddb74cf4f72cc61a308addb49caca6d4cf091d9fa0113ffa5c80623e72ccb", null ]
    ] ],
    [ "Type", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97db", [
      [ "BROWSE_FILE", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dbaae0187888f11e6908a5da8eed1554241", null ],
      [ "BROWSE_DIRECTORY", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dba0e302231f34729dcf3f620f06bb55e8f", null ],
      [ "BROWSE_MULTI_FILE", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dba58176e1efca763eb15232bdbd8094e7a", null ],
      [ "BROWSE_MULTI_DIRECTORY", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dbaa0f43f5cf1e3550ffe4cd8d0d4cd4804", null ],
      [ "BROWSE_SAVE_FILE", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dba83c4ad49cff0a28b6e1e920fcbb538d7", null ],
      [ "BROWSE_SAVE_DIRECTORY", "classFl__Native__File__Chooser.html#abd8d409b2f0d0114ac44eb34ba5b97dba8ef93017f4d8e2a738d3d2738d1edf87", null ]
    ] ],
    [ "Fl_Native_File_Chooser", "classFl__Native__File__Chooser.html#ab62790b5d3cbc8ef757c8ca632a3675e", null ],
    [ "~Fl_Native_File_Chooser", "classFl__Native__File__Chooser.html#a7e7dbacc435c93f02d1313e8996021d2", null ],
    [ "count", "classFl__Native__File__Chooser.html#af700f177a8d90abf942a43a51a3660f8", null ],
    [ "directory", "classFl__Native__File__Chooser.html#a21d2ceccc5b47bbb5e70082d75f4aeb1", null ],
    [ "directory", "classFl__Native__File__Chooser.html#ad6678bdd6ca4519253c160e3e61e09d5", null ],
    [ "errmsg", "classFl__Native__File__Chooser.html#a2a1b12426726b43fef918de732a7a10e", null ],
    [ "filename", "classFl__Native__File__Chooser.html#aaf5bb1463c094643bf924366ce9eeed8", null ],
    [ "filename", "classFl__Native__File__Chooser.html#a766b9c4cb20c60485578ae73047aeca6", null ],
    [ "filter", "classFl__Native__File__Chooser.html#a1736df13ce7ed38e290d15b9fbc1f072", null ],
    [ "filter", "classFl__Native__File__Chooser.html#abf9dc3286cc673070cc62bbdbdc07203", null ],
    [ "filter_value", "classFl__Native__File__Chooser.html#adf59d8ade1328ab3b63bac8f838d05f0", null ],
    [ "filter_value", "classFl__Native__File__Chooser.html#a10d5d4cbd82a1bcc939320c1341ef399", null ],
    [ "filters", "classFl__Native__File__Chooser.html#aba85883c0fc57772cd59d24aa1c4f67f", null ],
    [ "options", "classFl__Native__File__Chooser.html#a9c0256b7db881087e8d9bdd953ddf60a", null ],
    [ "options", "classFl__Native__File__Chooser.html#ae154a9b93417eae565c3eecc11ddb350", null ],
    [ "preset_file", "classFl__Native__File__Chooser.html#adcfb1c4830c3883c602343d2cfc44a73", null ],
    [ "preset_file", "classFl__Native__File__Chooser.html#aaa0bcf0f3ce7b2e5cb45c84a6c6ec722", null ],
    [ "show", "classFl__Native__File__Chooser.html#ac3c1724eea8f9f74a257cc198d69deb4", null ],
    [ "title", "classFl__Native__File__Chooser.html#a17c8c3d1ca584a126370bae4ca76bb17", null ],
    [ "title", "classFl__Native__File__Chooser.html#acdb3fc1218281082248a7e7286eafcb5", null ],
    [ "type", "classFl__Native__File__Chooser.html#a6182a341911517cd5eb3bfffba7bad35", null ],
    [ "type", "classFl__Native__File__Chooser.html#ae9c89557514353022e6f97bb1381871f", null ],
    [ "_gtk_file_chooser", "classFl__Native__File__Chooser.html#a4d4754da10482ab3956113769b02ebb4", null ],
    [ "_x11_file_chooser", "classFl__Native__File__Chooser.html#a50747eeb6616b2e2d2d998dbc1c2b733", null ]
];