var classFl__Gl__Choice =
[
    [ "best_fb", "classFl__Gl__Choice.html#a5febe71ff56d83593510260d248d74a9", null ],
    [ "colormap", "classFl__Gl__Choice.html#a97b061136e9b754d5cee29808fc0ebc2", null ],
    [ "vis", "classFl__Gl__Choice.html#a4fcf64a66a76a9f116656529521f0d5e", null ]
];