var structFl__Fontdesc =
[
    [ "first", "structFl__Fontdesc.html#a0480dd28e840d3fbb318ef433a89e1a4", null ],
    [ "fontname", "structFl__Fontdesc.html#a17bb45aa3941296348c85de1f0a0a4b1", null ],
    [ "n", "structFl__Fontdesc.html#a2e33fe9e5fb20fee9f4f6c0aeb554b5d", null ],
    [ "name", "structFl__Fontdesc.html#a69d67b2c506d7f5c2012681ebe94ca1c", null ],
    [ "xlist", "structFl__Fontdesc.html#ac1796333c80d01a634334c0c303dc4c0", null ]
];