var classFl__Printer =
[
    [ "Fl_Printer", "classFl__Printer.html#a82f5d6a0fe67c6b756251c6c2f470010", null ],
    [ "~Fl_Printer", "classFl__Printer.html#a9204f3ba398e223644aa43549f6c151f", null ],
    [ "class_name", "classFl__Printer.html#a8c51e8af2802d245d5a9d1cfa34413ae", null ],
    [ "driver", "classFl__Printer.html#aeb4f0b808abdb60b2af3d97a902d1058", null ],
    [ "end_job", "classFl__Printer.html#a181c505fbfba8818368f844f7276b06a", null ],
    [ "end_page", "classFl__Printer.html#ac3afd751b80f12a11f02a6e87eeb332a", null ],
    [ "margins", "classFl__Printer.html#ab0bb5557d714b1b8c0705c8af56bd26a", null ],
    [ "origin", "classFl__Printer.html#ab06af1da74d884b3acc3fd653bfa665e", null ],
    [ "origin", "classFl__Printer.html#ac373a57ae77016b7c0565361323ceebc", null ],
    [ "print_widget", "classFl__Printer.html#a0b6a37315107179fec2eab69008f5150", null ],
    [ "print_window_part", "classFl__Printer.html#afb75fad498e6e1eacd8d66f54a0964fd", null ],
    [ "printable_rect", "classFl__Printer.html#ae7d6d14dd0c0711634f38c599811db9c", null ],
    [ "rotate", "classFl__Printer.html#a2c5e858532b376ee7627369c9c8b1c36", null ],
    [ "scale", "classFl__Printer.html#a0b991bd8a66b8f5171cb1ee262834476", null ],
    [ "set_current", "classFl__Printer.html#af29bb9b0f186dae10d35e7a22a463ea4", null ],
    [ "start_job", "classFl__Printer.html#a8f3603112736f55dd08ef7ad4aaed551", null ],
    [ "start_page", "classFl__Printer.html#aa7c9294391ecebe05a59b868fe16bac1", null ],
    [ "translate", "classFl__Printer.html#a2b49948772a2fbe2d7a849ead465c36a", null ],
    [ "untranslate", "classFl__Printer.html#a76093f5f33d65cbdf94212da159069b0", null ]
];