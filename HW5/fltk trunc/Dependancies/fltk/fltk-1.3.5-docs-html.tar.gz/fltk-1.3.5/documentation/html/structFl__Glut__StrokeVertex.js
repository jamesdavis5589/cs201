var structFl__Glut__StrokeVertex =
[
    [ "X", "structFl__Glut__StrokeVertex.html#ae9798f36bbdfe85b11e21d0fce76b958", null ],
    [ "Y", "structFl__Glut__StrokeVertex.html#a884701d6b27cfe93392fca35fe7a2e17", null ]
];